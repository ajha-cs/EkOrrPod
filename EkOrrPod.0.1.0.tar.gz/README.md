# EkOrrPod

[![CI Status](https://img.shields.io/travis/ajha-cs/EkOrrPod.svg?style=flat)](https://travis-ci.org/ajha-cs/EkOrrPod)
[![Version](https://img.shields.io/cocoapods/0.1.0/EkOrrPod.svg?style=flat)](https://cocoapods.org/pods/EkOrrPod)
[![License](https://img.shields.io/cocoapods/MIT/EkOrrPod.svg?style=flat)](https://cocoapods.org/pods/EkOrrPod)
[![Platform](https://img.shields.io/cocoapods/osx/EkOrrPod.svg?style=flat)](https://cocoapods.org/pods/EkOrrPod)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

EkOrrPod is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'EkOrrPod'
```

## Author

ajha-cs, ajha@cloudsmith.io

## License

EkOrrPod is available under the MIT license. See the LICENSE file for more info.
