//
//  ViewController.swift
//  EkOrrPod
//
//  Created by 201456038 on 07/24/2025.
//  Copyright (c) 2025 201456038. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

  override func viewDidLoad() {
    super.viewDidLoad()

    // Do any additional setup after loading the view.
  }

  override var representedObject: Any? {
    didSet {
    // Update the view, if already loaded.
    }
  }


}

